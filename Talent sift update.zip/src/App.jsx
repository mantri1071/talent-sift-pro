import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { AnimatePresence, motion } from 'framer-motion';

import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import JobFormStep1 from '@/components/JobFormStep1';
import logo from './logo.png';
import axios from 'axios';

function App() {
  const [formData, setFormData] = useState({
    jobTitle: '',
    yearsOfExperience: '',
    jobType: '',
    location: '',
    requiredSkills: '',
    jobDescription: '',
    resumeFile: null, // Initialize resumeFile here
  });

  const { toast } = useToast();

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

 const handleSubmit = async () => {
  if (!formData.jobTitle || !formData.jobType || !formData.jobDescription) {
    toast({
      title: "Missing Information",
      description: "Please fill in all required fields before submitting.",
      variant: "destructive"
    });
    return;
  }

  if (!formData.resumeFile) {
    toast({
      title: "Missing Resume",
      description: "Please upload a resume before submitting.",
      variant: "destructive"
    });
    return;
  }

  try {
    const form = new FormData();

    const jobPayload = {
      workflow_id: 'resume_ranker',
      job_description: formData.jobDescription || 'No description'
    };

    form.append('data', JSON.stringify(jobPayload));

    form.append('resumes', formData.resumeFile);
        // Send to backend API
        const backendResponse = await axios.post('https://65.2.166.232/api/agentic-ai/workflow-exe', form, {
          headers: {
            'Content-Type': 'multipart/form-data'
          },
          timeout: 30000
        });
        const temp = backendResponse.data.data;
        console.log('temp:',temp);


    const url = 'https://dev187243.service-now.com/api/1763965/resumerankingapi/upload';

    const response = await axios.post(url, form, {
      auth: {
        username: 'admin',
        password: 'aTw3Prz$PR/7'
      },
      headers: {
        Accept: 'application/json'
        // Don't manually set Content-Type with FormData
      }
    });

    toast({
      title: "Success!",
      description: "✅ Resume submitted to ServiceNow successfully.",
    });

  } catch (error) {
    console.error('❌ Upload failed:', error);
    toast({
      title: "Upload Failed",
      description: "❌ Something went wrong. Check the console for details.",
      variant: "destructive"
    });
  }
};


  const props = {
    formData,
    handleInputChange,
    handleSubmit,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-350 via-blue-500 to-blue-600 relative overflow-hidden">
      <Helmet>
        <title>Talent Sift - Job Posting Platform</title>
        <meta name="description" content="Create and post job opportunities with Talent Sift's intuitive job posting platform" />
      </Helmet>

      <motion.div
        className="absolute inset-0 opacity-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.1 }}
        transition={{ duration: 1 }}
      >
        <div className="absolute top-20 left-20 w-32 h-32 bg-white rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-white rounded-full blur-xl animate-pulse delay-500"></div>
        <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-white rounded-full blur-lg animate-pulse delay-1000"></div>
      </motion.div>

      <div className="relative z-10 min-h-screen flex flex-col">
        <div className="p-8">
          <img src={logo} alt="Start IT Now Logo" className="h-10" />
        </div>

        <div className="flex-1 flex items-center justify-center p-4">
            { <JobFormStep1 {...props} />}
            </div>

      <Toaster />
    </div>
    </div>
  );
}

export default App;
